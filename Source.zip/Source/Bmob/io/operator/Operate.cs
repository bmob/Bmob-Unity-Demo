﻿
namespace cn.bmob.io
{
    internal class Operate : BmobObject
    {
        public const string OP_NAME = "__op";

    }
}
