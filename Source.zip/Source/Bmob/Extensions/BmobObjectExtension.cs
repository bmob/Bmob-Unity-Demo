﻿/*
using cn.bmob.api;
using cn.bmob.io;
using cn.bmob.response;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace cn.bmob.Extensions
{
    public static class BmobObjectExtensions
    {
        public static Object Select(this BmobObject input)
        {
            return null;
        }

        public static BmobQuery Select(this BmobQuery input)
        {
            return input;
        }

        public static BmobQuery Where(this String input, Expression<Func<BmobTable, bool>> predicate)
        {
            return input;
        }

        public static BmobQuery Order(this BmobQuery input)
        {
            return input;
        }
    }
}
*/