﻿using cn.bmob.io;

namespace cn.bmob.response
{
    /// <summary>
    /// 没有具体内容的返回值
    /// </summary>
    public class EmptyCallbackData : BmobObject, IBmobWritable
    {
    }
}
